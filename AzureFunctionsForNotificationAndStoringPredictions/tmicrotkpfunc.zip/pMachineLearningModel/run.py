import os
import json
import platform
import requests
import random
import time
import datetime
import sys
import uuid



#getting the current time for sending it as part of the notification
ts = time.time()

#getting timestamp as the string specified in the format below
st = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')

resp = 0
receivedBody = json.loads(open(os.environ['MYEVENTHUBMESSAGE']).read())


try:
    print('Received body:', receivedBody)
    #calling the deep learning model for predictive maintenance service
    par1 = receivedBody['L3_S30_D3521']
    url = "http://40.91.209.16/?par1=" + str(par1)
    print(url)
    r = requests.get(url)
    print(r)
    l_response = int(r.text)
    print(l_response)
    resp = l_response
except:
    resp = random.choice([1, 0])

outcosmosdb = { "id" : receivedBody['id'],
                "prediction"   : resp}
print(outcosmosdb)

#Send email using SendGrid (output name: outputMessage)
with open(os.environ["outputDocument"], 'w') as f:
    json.dump(outcosmosdb,f)

if resp == 1: 
    resp_body = "A new fault is detected at the production site for machine number 1011 at time " + st 
    print(resp_body)
    
    outsms = { "body" : resp_body,
               "to"   : "+4917643308311"}
    #Send email using SendGrid (output name: outputMessage)
    with open(os.environ["smsmessage"], 'w') as f:
        json.dump(outsms,f)
    

else:
    print("Nothing to worry about!")